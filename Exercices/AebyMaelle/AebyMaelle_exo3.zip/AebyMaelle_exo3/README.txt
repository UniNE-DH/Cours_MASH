Dans ce dossier:
* Un dossier ROMA contenant:
    -   un document HTML
    -   mon ODD en XML
    -   mon sch�ma en RNC 
* Un document XML appel� "AebyMa�lle_exo2WithODD" contenant mon exercice final reli� � mon sch�ma en RNC. 

