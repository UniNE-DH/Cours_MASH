Dans ce dossier se trouvent plusieurs �l�ments g�n�r�s apr�s le cours du 18.11.2019 pour le cours des humanit�s num�riques donn� en cours de master en histoire par Simon Gabay � l'Universit� de Neuch�tel:
-Un dossier Sch�ma avec mon sch�ma en Relax NG Compact Syntax
-Un dossier Documentation avec un ODD et une page html
-Mon fichier xml nomm� exercice11.11.2019
-Un projet Oxygen nomm� newProject