Il y aura dans ce dossier
- README qui indique ce que contient le DossierEx3
- un ODD qui s'appelle monODD
- une page html nomm�e myTEI_doc
- un dossier schema dans lequel se trouve mon schema en Relax NG compact syntax
- mon �dition xml qui s'appelle Ex2.xml